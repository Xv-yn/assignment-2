import json,sys,numpy as np
from pathlib import Path
import matplotlib; matplotlib.use('Agg')
import matplotlib.pyplot as plt
R=Path(sys.argv[1])/'experiment_results/final'; O=Path(sys.argv[2])
plt.rcParams.update({'font.family':'serif','font.serif':['Nimbus Roman','Times New Roman','STIXGeneral','DejaVu Serif'],
 'mathtext.fontset':'stix','font.size':9,'axes.titlesize':9.5,'axes.labelsize':9,'xtick.labelsize':8,'ytick.labelsize':8,
 'legend.fontsize':8,'axes.spines.top':False,'axes.spines.right':False,'pdf.fonttype':42})
DS=['FashionMNIST0.3','FashionMNIST0.6','CIFAR']; C={'forward':'#2a6fb0','gce':'#d0782a'}; L={'forward':'Forward','gce':'GCE'}
# Fig 1 accuracy paired (CE baseline + two robust methods)
import csv
CEP=Path(sys.argv[3]) if len(sys.argv)>3 else None
cerows=list(csv.DictReader(open(CEP))) if CEP else []
M=(['ce'] if cerows else [])+['forward','gce']; CC={'ce':'#7a7a7a','forward':C['forward'],'gce':C['gce']}; LL={'ce':'CE','forward':'Forward','gce':'GCE'}
fig,ax=plt.subplots(1,3,figsize=(5.5,2.35))
for a,d in zip(ax,DS):
    acc={m:np.array([json.load(open(R/d/f'seed_{s:03d}'/m/'metrics.json'))['test_top1_percent'] for s in range(10)]) for m in ['forward','gce']}
    if cerows: acc['ce']=np.array([float(r['test_top1_percent']) for r in sorted(cerows,key=lambda r:int(r['split_seed'])) if r['dataset']==d])
    for s in range(10): a.plot(range(len(M)),[acc[m][s] for m in M],color='0.82',lw=0.6,zorder=1)
    for i,m in enumerate(M):
        a.scatter(np.full(10,i),acc[m],s=10,color=CC[m],zorder=2,alpha=.85,edgecolor='none')
        mu,sd=acc[m].mean(),acc[m].std(ddof=1)
        a.errorbar(i+0.2,mu,yerr=sd,fmt='D',ms=3.5,color='k',capsize=2,lw=0.9,zorder=3)
    a.set_xticks(range(len(M)));a.set_xticklabels([LL[m] for m in M],fontsize=8);a.set_xlim(-0.4,len(M)-0.5);a.set_title(d.replace('FashionMNIST','FMNIST'))
ax[0].set_ylabel('Clean test top-1 accuracy (%)')
fig.tight_layout(w_pad=1.0); fig.savefig(O/'fig_accuracy.pdf'); plt.close(fig)
# Fig 2 validation curves (Forward only): mean +- SD band, selected checkpoints, chance level and noise-entropy floor
def H(r):
    r=np.asarray(r,float); r=r[r>0]; return float(-(r*np.log(r)).sum())
TT={'FashionMNIST0.3':[[.7,.3,0],[0,.7,.3],[.3,0,.7]],'FashionMNIST0.6':[[.4,.3,.3],[.3,.4,.3],[.3,.3,.4]]}
fig,ax=plt.subplots(1,3,figsize=(5.5,2.3))
for a,d in zip(ax,DS):
    if d in TT: T=np.array(TT[d])
    else: T=np.mean([json.load(open(R/d/f'seed_{s:03d}'/'estimator/transition.json'))['estimated_transition'] for s in range(10)],0)
    floor=np.mean([H(r) for r in T]); chance=np.log(3)
    hs=[json.load(open(R/d/f'seed_{s:03d}'/'forward'/'history.json')) for s in range(10)]
    curves=[[e['validation_noisy_nll'] for e in h['epochs']] for h in hs]
    n=max(map(len,curves)); cnt=[sum(len(c)>i for c in curves) for i in range(n)]; k=max(i for i in range(n) if cnt[i]>=5)+1
    mean=np.array([np.mean([c[i] for c in curves if len(c)>i]) for i in range(k)])
    sd=np.array([np.std([c[i] for c in curves if len(c)>i]) for i in range(k)])
    x=np.arange(1,k+1)
    a.fill_between(x,mean-sd,mean+sd,color=C['forward'],alpha=.18,lw=0)
    a.plot(x,mean,color=C['forward'],lw=1.6,label='Forward (mean $\\pm$ SD)')
    be=[h['best_epoch'] for h in hs]; bv=[c[b-1] for c,b in zip(curves,be)]
    a.scatter(be,bv,s=11,color='k',zorder=3,label='selected checkpoint')
    a.axhline(floor,color='#2e8b57',ls=':',lw=1.2,label='noise-entropy floor')
    if d!='FashionMNIST0.3': a.axhline(chance,color='0.35',ls='--',lw=1.0,label='chance level $\\ln 3$')
    lo=min(floor,min(mean-sd),min(bv)); hi=max(max(mean+sd),chance if d!='FashionMNIST0.3' else max(mean+sd))
    pad=(hi-lo)*0.12; a.set_ylim(lo-pad,hi+pad); a.set_xlim(0.5,k+0.5)
    a.set_title(d.replace('FashionMNIST','FMNIST')); a.set_xlabel('Epoch')
ax[0].set_ylabel('Noisy validation NLL')
h1,l1=ax[1].get_legend_handles_labels()
fig.legend(h1,l1,loc='lower center',ncol=4,frameon=False,fontsize=7.5,bbox_to_anchor=(0.5,-0.01))
fig.tight_layout(w_pad=1.0,rect=(0,0.08,1,1)); fig.savefig(O/'fig_curves.pdf'); plt.close(fig)
# Fig 3 heatmaps
K={'FashionMNIST0.3':np.array([[.7,.3,0],[0,.7,.3],[.3,0,.7]]),'FashionMNIST0.6':np.array([[.4,.3,.3],[.3,.4,.3],[.3,.3,.4]])}
mats=[];titles=[]
for d in DS:
    Ts=np.array([json.load(open(R/d/f'seed_{s:03d}'/'estimator/transition.json'))['estimated_transition'] for s in range(10)])
    if d in K: mats.append((K[d],None)); titles.append(d.replace('FashionMNIST','FMNIST')+' true $T$')
    mats.append((Ts.mean(0),Ts.std(0,ddof=1))); titles.append(d.replace('FashionMNIST','FMNIST')+r' $\hat T$')
fig,ax=plt.subplots(1,5,figsize=(5.5,2.0))
for a,(M,SD),t in zip(ax,mats,titles):
    a.imshow(M,cmap='Blues',vmin=0,vmax=1)
    for i in range(3):
        for j in range(3):
            s=f'{M[i,j]:.2f}' if SD is None else f'{M[i,j]:.2f}\n±{SD[i,j]:.2f}'
            a.text(j,i,s,ha='center',va='center',fontsize=7.2 if SD is not None else 8,color='white' if M[i,j]>0.55 else 'black',linespacing=0.9)
    a.set_xticks(range(3));a.set_yticks(range(3));a.tick_params(length=0,labelsize=7);a.set_title(t,fontsize=8)
    for sp in a.spines.values(): sp.set_visible(False)
ax[0].set_ylabel('clean $Y$',fontsize=8); 
for a in ax: a.set_xlabel('noisy $\\tilde Y$',fontsize=7.5)
fig.tight_layout(w_pad=0.4); fig.savefig(O/'fig_transition.pdf',bbox_inches='tight',pad_inches=0.02); plt.close(fig)
